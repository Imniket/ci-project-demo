<!DOCTYPE html>
<html>
<head>
<title>Sample</title>
<!-- For-Mobile-Apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Arbitrary a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //For-Mobile-Apps -->
<!-- Custom-Stylesheet-Links -->
	<link rel="stylesheet" href="<?php echo base_url('asset/css/bootstrap.min.css'); ?>" type="text/css" media="all"/>
	<link rel="stylesheet" href="<?php echo base_url('asset/css/style.css'); ?>" type="text/css" media="all" />
	<link rel="stylesheet" href="<?php echo base_url('asset/css/flexslider.css') ?>;" type="text/css" media="screen" />
        <link rel="stylesheet" href="<?php echo base_url('asset/css/flexslider.css'); ?>" type="text/css" media="screen" />
<!-- //Custom-Stylesheet-Links -->
<!-- Web-Fonts -->
	<link href='//fonts.googleapis.com/css?family=Hammersmith+One' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
<!-- //Web-Fonts -->

<script type="text/javascript" src="<?php echo base_url('asset/js/jquery-1.8.2.min.js'); ?>"></script>
 <script type="text/javascript" src="<?php echo base_url('asset/js/jquery.min.js'); ?>"></script>
 <script type="text/javascript" src="<?php echo base_url('asset/js/jquery.validate.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/js/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/ckeditor/ckeditor.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('asset/js/validation.js');?>"></script>
    
     <script src="<?php echo base_url('asset/') ; ?>js/jssor.slider-25.2.0.min.js" type="text/javascript"></script>

<!--gallery-->
<!--JS for animate-->
	<link href="<?php echo base_url('asset/css/animate.css'); ?>" rel="stylesheet" type="text/css" media="all">
	<script src="<?php echo base_url('asset/js/wow.min.js'); ?>"></script>
		<script>
			new WOW().init();
		</script>
	<!--//end-animate-->
</head>
<body>
    