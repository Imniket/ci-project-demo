<!-- gallery -->
<div class="gallery wthree-3">
    <div class="container">
        <h1>Gallery</h1> 

        <script src="<?php echo base_url('asset/js/jquery.swipebox.min.js'); ?>"></script> 
        <script type="text/javascript">
          jQuery(function ($) {
              $(".swipebox").swipebox();
          });
        </script>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/1.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/1.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h2>Vulputate Velit</h2>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/2.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/2.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/3.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/3.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/4.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/4.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/5.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/5.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/6.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/6.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/7.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/7.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet.</p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/8.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/8.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet.</p>

                </div></a>
        </div>
        <div class="view view-seventh">
            <a href="<?php echo base_url('asset/images/9.jpg'); ?>" class="b-link-stripe b-animate-go  swipebox" title="Image Title"><img src="<?php echo base_url('asset/images/9.jpg'); ?>" alt="" class="img-responsive">
                <div class="mask">
                    <h3>Vulputate Velit</h3>
                    <p>Were dolor in hendrerit in vulputate velit esse molestie con sequat,Nulla consectetur maximus sem vel aliquet. </p>

                </div></a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- //gallery -->